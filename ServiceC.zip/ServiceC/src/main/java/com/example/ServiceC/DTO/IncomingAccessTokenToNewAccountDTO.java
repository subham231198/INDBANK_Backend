package com.example.ServiceC.DTO;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncomingAccessTokenToNewAccountDTO {
    @JsonProperty(value = "input_token_state")
    private InputTokenState inputTokenState;

    @JsonProperty(value = "output_token_state")
    private OutputTokenState outputTokenState;
}
