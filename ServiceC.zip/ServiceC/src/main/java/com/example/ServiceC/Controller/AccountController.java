package com.example.ServiceC.Controller;

import com.example.ServiceC.DTO.IncomingAccessTokenToNewAccountDTO;
import com.example.ServiceC.Service.AccountService;
import io.swagger.v3.oas.annotations.Parameter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private RestTemplate restTemplate;

    private static final Logger logger = LogManager.getLogger(AccountController.class);

    @GetMapping(
            value = "/v1/accesstoken_to_newaccount",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Parameter(description = "To retrieve a account which is in NEW state by using access token")
    public ResponseEntity<?> getAccount(
            @AuthenticationPrincipal Jwt jwt,
            @RequestBody IncomingAccessTokenToNewAccountDTO request
    ) {

        if(!request.getInputTokenState().getToken_type().equals("ACCESSTOKEN")){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid input_token_type provided!");
        }

        if(request.getOutputTokenState().getProduct_type()==null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "product_type cannot be null!");
        }

        logger.info("Incoming request: "+request.toString());

        String headerToken = jwt.getTokenValue();
        if(!request.getInputTokenState().getTokenId().equals(headerToken)){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Access Denied!");
        }

        if(!request.getOutputTokenState().getToken_type().equals("ACCTJWT")){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid output_token_type provided!");
        }

        if(request.getInputTokenState()==null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "input_token_state cannot be null!");
        }

        if(request.getOutputTokenState()==null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "output_token_state cannot be null!");
        }
        return accountService.retrieveNewServiceAccount(jwt, request.getOutputTokenState().getProduct_type());
    }

    @PostMapping(
            value = "/v1/active/account/verify",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Parameter(description = "To verify an active account record exists in database")
    public ResponseEntity<?> isNewAccountExist(
            @AuthenticationPrincipal Jwt jwt,
            @RequestParam("type") String productType,
            @RequestParam("status") String status,
            @RequestParam("state") String state
    ){
        if(productType==null || productType.isEmpty()
                || status==null || status.isEmpty()
                || state==null || state.isEmpty()

        ){
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Missing query params!");
        }

        if(!status.equals("NEW") && !status.equals("CONSUMED")){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Access Denied!");
        }

        if(!state.equals("ACTIVE")){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Access Denied!");
        }
        return accountService.validateAccountExist(jwt, productType, status, state);
    }
}