package com.example.ServiceC.Configuration;


import com.example.ServiceC.DTO.UserAuthDTO;
import com.example.ServiceC.Entity.OAuthClientEntity;
import com.example.ServiceC.Repository.OAuthClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configurers.OAuth2AuthorizationServerConfigurer;
import org.springframework.security.oauth2.server.authorization.settings.AuthorizationServerSettings;
import org.springframework.security.oauth2.server.authorization.settings.ClientSettings;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

import java.util.Optional;
import java.util.UUID;

@Configuration
public class AuthorizationServerConfig {

    @Autowired
    private UserAuthDTO userAuthDTO;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Order(1)
    public SecurityFilterChain authorizationServerSecurityFilterChain(HttpSecurity http) throws Exception {

        OAuth2AuthorizationServerConfigurer authorizationServerConfigurer =
                OAuth2AuthorizationServerConfigurer.authorizationServer();

        authorizationServerConfigurer.oidc(Customizer.withDefaults());

        http.securityMatcher(authorizationServerConfigurer.getEndpointsMatcher())
                .with(authorizationServerConfigurer, Customizer.withDefaults());

        http.exceptionHandling(ex ->
                ex.authenticationEntryPoint(new LoginUrlAuthenticationEntryPoint("/login"))
        );

        return http.build();
    }

    @Bean
    @Order(2)
    public SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {

        http.authorizeHttpRequests(auth -> auth
                    .requestMatchers(
                            "/login",
                            "/health",
                            "/v1/oauth/authorize",
                            "oauth2/authorize",
                            "/v1/accesstoken_to_newaccount",
                            "/oauth2/introspect",
                            "/v1/active/account/verify",
                            "/v1/kafka/getAllListeners"
                    ).permitAll()
                    .anyRequest().authenticated()
                )
                .csrf(AbstractHttpConfigurer::disable)
                .oauth2ResourceServer(oauth2 -> oauth2.jwt(Customizer.withDefaults()))
                .formLogin(Customizer.withDefaults())
                .formLogin(form -> form
                    .defaultSuccessUrl("/oauth2/authorize", true)
                    .permitAll())
                .logout(logout -> logout
                    .logoutSuccessUrl("/login?logout")
                    .permitAll()
                );

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {

        String username = UUID.randomUUID().toString();
        String password = UUID.randomUUID().toString();
        UserDetails user = User.withUsername(username)
                .password(passwordEncoder().encode(password))
                .roles("USER")
                .build();

        System.out.println("Username: "+username);
        System.out.println("Password: "+password);

        userAuthDTO.setUsername(username);
        userAuthDTO.setPassword(password);

        return new InMemoryUserDetailsManager(user);
    }

    @Bean
    public RegisteredClientRepository registeredClientRepository(OAuthClientRepository clientRepository) {

       return new RegisteredClientRepository() {
           @Override
           public void save(RegisteredClient registeredClient) {

           }

           @Override
           public RegisteredClient findById(String id) {
               return null;
           }

           @Override
           public RegisteredClient findByClientId(String clientId) {
               Optional<OAuthClientEntity> entity = clientRepository.findByClientId(clientId);
               if (!entity.isPresent()) {
                   return null;
               }

               OAuthClientEntity client = entity.get();

               if(entity.get().getGrantTypes().equalsIgnoreCase("client_credentials")){
                   return RegisteredClient.withId(client.getId().toString())
                           .clientId(client.getClientId())
                           .clientSecret(client.getClientSecret())
                           .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                           .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                           .scope(client.getScopes())
                           .build();
               }
               else if(entity.get().getGrantTypes().equalsIgnoreCase("authorization_code")){
                   return RegisteredClient.withId(client.getId().toString())
                           .clientId(client.getClientId())
                           .clientSecret(client.getClientSecret())
                           .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                           .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                           .authorizationGrantType(AuthorizationGrantType.REFRESH_TOKEN)
                           .redirectUri(entity.get().getRedirectUri())
                           .scope(client.getScopes())
                           .clientSettings(ClientSettings.builder()
                                   .requireProofKey(false)
                                   .build())
                           .build();
               }
               return null;
           }
       };
    }

    @Bean
    public AuthorizationServerSettings authorizationServerSettings() {
        return AuthorizationServerSettings.builder()
                .issuer("http://localhost:9091")
                .tokenIntrospectionEndpoint("/oauth2/introspect")
                .build();
    }
}
