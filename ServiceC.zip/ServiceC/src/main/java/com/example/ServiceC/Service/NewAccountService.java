package com.example.ServiceC.Service;

import com.example.ServiceC.Entity.AccountsEntity;
import com.example.ServiceC.Repository.AccountsRepo;
import com.example.ServiceC.Utility.AccountGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Map;

@Service
@Transactional
public class NewAccountService {

    @Autowired
    private AccountsRepo accountsRepo;

    @Autowired
    private AccountGenerator accountGenerator;

    private static final Logger logger = LogManager.getLogger(NewAccountService.class);

    ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "account-creation-requests", groupId = "service-c-group")
    public void kafkaListener(String message) {
        Map<String, Object> messageMap = null;
        try {
            messageMap = objectMapper.readValue(message, Map.class);
        }
        catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        String productType = (String) messageMap.get("accountType");
        String status = (String) messageMap.get("status");
        String state = (String) messageMap.get("state");

        logger.info("Received account creation request from Kafka topic 'account-creation-requests': {}", message);
        createAccount(productType, status, state);
    }

    public ResponseEntity<?> createAccount(String productType, String status, String state) {
        String sortCode = accountGenerator.generateSortCode();
        String accountNumber = accountGenerator.generateAccountNumber();
        while (accountsRepo.existsBySortCodeAndAccountNumber(sortCode, accountNumber))
        {
            sortCode = accountGenerator.generateSortCode();
            accountNumber = accountGenerator.generateAccountNumber();
        }
        AccountsEntity newAccount = new AccountsEntity();
        newAccount.setProductType(productType.toUpperCase());
        if(productType == null || status == null || state == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Missing required fields in the request message"));
        }
        else if(productType.equalsIgnoreCase("SAVINGS")) {
            newAccount.setProductCode("SA101");
        }
        else if (productType.equalsIgnoreCase("CURRENT")) {
            newAccount.setProductCode("CA101");
        }
        else {
            return ResponseEntity.badRequest().body(Map.of("message", "Invalid product type: " + productType));
        }
        newAccount.setAccountStatus(status.toUpperCase());
        newAccount.setAccountState(state.toUpperCase());
        newAccount.setSortCode(sortCode);
        newAccount.setAccountNumber(accountNumber);
        newAccount.setCreatedAt(Instant.now().toString());

        accountsRepo.saveAndFlush(newAccount);
        return ResponseEntity.ok(Map.of("message", "Account created for product type: " + productType));
    }
}
