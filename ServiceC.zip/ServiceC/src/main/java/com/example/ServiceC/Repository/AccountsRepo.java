package com.example.ServiceC.Repository;

import com.example.ServiceC.Entity.AccountsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AccountsRepo extends JpaRepository<AccountsEntity, Long> {

    Optional<AccountsEntity> findBySortCode(String sortCode);
    Optional<AccountsEntity> findByAccountNumber(String accountNumber);
    Optional<AccountsEntity> findBySortCodeAndAccountNumber(String sort_code, String account_number);
    Boolean existsBySortCodeAndAccountNumber(String sort_code, String account_number);
    Boolean existsByProductTypeAndAccountStatusAndAccountState(
            String productType,
            String accountStatus,
            String accountState
    );
    Optional<AccountsEntity> findFirstByProductTypeAndAccountStatusAndAccountState(
            String productType,
            String accountStatus,
            String accountState
    );
}
