package com.example.ServiceC.Exception;

import com.example.ServiceC.DTO.APIResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.LinkedHashMap;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<APIResponse<Void>> handleResponseStatus(
            ResponseStatusException ex
    ) {

        String reason = switch (ex.getStatusCode().value()) {

            case 400 -> "Bad Request";

            case 401 -> "Unauthorized";

            case 403 -> "Forbidden";

            case 404 -> "Not Found";

            case 500 -> "Internal Server Error";

            default -> "Unexpected Error";
        };

        APIResponse<Void> response =
                new APIResponse<>(
                        ex.getStatusCode().value(),
                        reason,
                        ex.getReason() != null
                                ? ex.getReason()
                                : "Unexpected error"
                );

        return new ResponseEntity<>(
                response,
                ex.getStatusCode()
        );
    }

}
