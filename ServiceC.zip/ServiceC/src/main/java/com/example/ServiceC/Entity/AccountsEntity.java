package com.example.ServiceC.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(
        name = "service_accounts_table",
        uniqueConstraints = {
                @UniqueConstraint(
                        columnNames = {
                                "sort_code",
                                "account_number"
                        }
                )
        }
)
public class AccountsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;

    @Column(name = "product_type")
    private String productType;

    @Column(name = "product_code")
    private String productCode;

    @Column(name = "sort_code", nullable = false)
    private String sortCode;

    @Column(name = "account_number", nullable = false)
    private String accountNumber;

    @Column(name = "account_status")
    private String accountStatus;

    @Column(name = "account_state")
    private String accountState;

    @Column(name = "created_at")
    private String createdAt;
}
