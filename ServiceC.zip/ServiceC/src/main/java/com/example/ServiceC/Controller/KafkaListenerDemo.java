package com.example.ServiceC.Controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.catalina.mapper.Mapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@RestController
public class KafkaListenerDemo {


    List<Map<String, Object>> receivedMessages = new LinkedList<>();

    private static final Logger logger = LogManager.getLogger(KafkaListenerDemo.class);


    @KafkaListener(topics = "Practise", groupId = "service-c-group")
    public void listenToKafkaTopic(String message) {
            logger.info("Received message from Kafka topic 'Practise': {}", message);
            Map<String, Object> messageMap = Map.of(
                    "message", message
            );
            receivedMessages.add(messageMap);
    }

    @GetMapping("/v1/kafka/getAllListeners")
    public List<Map<String, Object>> getAllListeners() {
        return receivedMessages;
    }

}
