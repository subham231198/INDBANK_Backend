package com.example.ServiceC.Utility;

import org.springframework.stereotype.Component;

import java.util.concurrent.ThreadLocalRandom;

@Component
public class AccountGenerator {

    public String generateSortCode() {
        int num = ThreadLocalRandom.current().nextInt(0, 1_000_000);
        return String.format("%06d", num);
    }


    public String generateAccountNumber() {
        long num = (long)(ThreadLocalRandom.current().nextDouble() * 1_000_000_000_000L);
        return String.format("%012d", num);
    }
}