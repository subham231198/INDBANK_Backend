package com.example.ServiceC.Service;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.example.ServiceC.Entity.AccountsEntity;
import com.example.ServiceC.Repository.AccountsRepo;
import com.example.ServiceC.Utility.JWTBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AccountService {

    @Autowired
    private JWTBuilder jwtBuilder;

    @Autowired
    private AccountsRepo accountsRepo;

    public ResponseEntity<?> retrieveNewServiceAccount(Jwt jwt, String productType) {

        try {

            validateJwt(jwt, "newAccount");

            String userId = jwt.getSubject();
            String keyId = jwtBuilder.extractKid(jwt.getTokenValue());

            AccountsEntity account = accountsRepo
                    .findFirstByProductTypeAndAccountStatusAndAccountState(
                            productType.toUpperCase(),
                            "NEW",
                            "ACTIVE"
                    )
                    .orElseThrow(() ->
                            new ResponseStatusException(
                                    HttpStatus.NOT_FOUND,
                                    "Product not found!"
                            )
                    );

            String accountJwt = buildAccountJwt(
                    keyId,
                    userId,
                    account
            );

            Map<String, Object> response = new HashMap<>();
            response.put("scope", jwt.getClaimAsStringList("scope"));
            response.put("issued_jwt", accountJwt);

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity.status(401)
                    .body(Map.of(
                            "error",
                            "Invalid or expired token: " + e.getMessage()
                    ));
        }
    }

    public ResponseEntity<?> validateAccountExist(
            Jwt jwt,
            String productType,
            String status,
            String state
    ) {

        validateJwt(jwt, "validate");

        boolean exists = accountsRepo
                .findFirstByProductTypeAndAccountStatusAndAccountState(
                        productType.toUpperCase(),
                        status.toUpperCase(),
                        state.toUpperCase()
                )
                .isPresent();

        if(exists){
            return new ResponseEntity<>(
                    Map.of(
                            "isAccountExist", true
                    ), HttpStatus.OK
            );
        }
        return new ResponseEntity<>(
                Map.of(
                        "isAccountExist", false
                ), HttpStatus.OK
        );

    }

    private void validateJwt(Jwt jwt, String purpose) {

        if (jwt == null) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "No JWT token provided"
            );
        }

        String userId = jwt.getSubject();

        if (userId == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "userId null in access_token!"
            );
        }

        List<String> scopes = jwt.getClaimAsStringList("scope");

        if(purpose.equalsIgnoreCase("newAccount")){
            if (scopes == null ||
                    (!scopes.contains("openid"))) {

                throw new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Access Denied!"
                );
            }
        }
    }

    private String buildAccountJwt(
            String keyId,
            String userId,
            AccountsEntity account
    ) {

        return jwtBuilder.generateNewAccounts_JWT(
                keyId,
                userId,
                account.getSortCode(),
                account.getAccountNumber(),
                account.getProductType(),
                account.getAccountStatus(),
                account.getAccountState(),
                account.getCreatedAt()
        );
    }
}