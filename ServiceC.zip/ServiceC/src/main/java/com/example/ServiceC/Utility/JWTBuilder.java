package com.example.ServiceC.Utility;


import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.nimbusds.jwt.SignedJWT;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.Getter;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class JWTBuilder {
    private final String SECRET = "c2VjdXJlUmFuZG9tSFM1NlNlY3JldEtleUZvckpXVDEyMzQ1Njc4OTA=";

    @Getter
    private final SecretKey secretKey = Keys.hmacShaKeyFor(SECRET.getBytes());

    public String generateNewAccounts_JWT(
            String keyId,
            String clientId,
            String sortCode,
            String accountNumner,
            String product_type,
            String status,
            String state,
            String createdAt) {

        return Jwts.builder()
                .setHeaderParam("kid", keyId)
                .subject(clientId)
                .claim("sort_code", sortCode)
                .claim("account_number", accountNumner)
                .claim("account_type", product_type)
                .claim("createdAt", createdAt)
                .claim("account_status", status)
                .claim("state", state)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + 1000 * 60))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();
    }

    public Map<String, Object> decodePayload(String token) {

        DecodedJWT decodedJWT = JWT.decode(token);

        Map<String, Object> claimsMap = new ConcurrentHashMap<>();

        decodedJWT.getClaims().forEach((key, claim) -> {
            if (claim.as(Object.class) != null) {
                claimsMap.put(key, claim.as(Object.class));
            }
        });

        return claimsMap;
    }

    public String extractKid(String jwtToken) throws Exception {
        SignedJWT signedJWT = SignedJWT.parse(jwtToken);
        return signedJWT.getHeader().getKeyID();
    }
}
