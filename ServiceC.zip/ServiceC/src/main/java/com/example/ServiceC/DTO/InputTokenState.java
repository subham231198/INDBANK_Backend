package com.example.ServiceC.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InputTokenState {

    @JsonProperty(value = "token_type")
    private String token_type;

    @JsonProperty(value = "tokenId")
    private String tokenId;
}
