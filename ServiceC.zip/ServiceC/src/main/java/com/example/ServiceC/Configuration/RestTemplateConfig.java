package com.example.ServiceC.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

    @Bean
    public RestTemplate restTemplate() {

        org.apache.hc.client5.http.cookie.CookieStore cookieStore =
                new org.apache.hc.client5.http.cookie.BasicCookieStore();

        org.apache.hc.client5.http.config.RequestConfig config =
                org.apache.hc.client5.http.config.RequestConfig.custom()
                        .setRedirectsEnabled(false)
                        .build();

        org.apache.hc.client5.http.impl.classic.CloseableHttpClient client =
                org.apache.hc.client5.http.impl.classic.HttpClients.custom()
                        .setDefaultCookieStore(cookieStore)
                        .setDefaultRequestConfig(config)
                        .build();

        return new RestTemplate(
                new org.springframework.http.client.HttpComponentsClientHttpRequestFactory(client)
        );
    }
}