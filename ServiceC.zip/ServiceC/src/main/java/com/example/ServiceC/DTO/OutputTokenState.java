package com.example.ServiceC.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OutputTokenState {

    @JsonProperty(value = "token_type")
    private String token_type;

    @JsonProperty(value = "product_type")
    private String product_type;

    @JsonProperty(value = "message")
    private String message;
}
