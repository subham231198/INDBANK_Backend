package com.example.ServiceC.Tests;


import com.example.ServiceC.Entity.AccountsEntity;
import com.example.ServiceC.Repository.AccountsRepo;
import com.example.ServiceC.Utility.AccountGenerator;
import io.jsonwebtoken.lang.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.annotation.Rollback;

import java.time.Instant;
import java.util.Optional;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
public class AccountServiceTest {


    AccountGenerator accountGenerator = new AccountGenerator();

    @Autowired
    AccountsRepo accountsRepo;


    public void createNewSavingsAccount(){

        String sortCode = accountGenerator.generateSortCode();
        String accountNumber = accountGenerator.generateAccountNumber();
        while (accountsRepo.existsBySortCodeAndAccountNumber(sortCode, accountNumber))
        {
            sortCode = accountGenerator.generateSortCode();
            accountNumber = accountGenerator.generateAccountNumber();
        }
        AccountsEntity accountsEntity = new AccountsEntity();
        accountsEntity.setSortCode(sortCode);
        accountsEntity.setAccountNumber(accountNumber);
        accountsEntity.setAccountStatus("NEW");
        accountsEntity.setAccountState("ACTIVE");
        accountsEntity.setProductType("Current");
        accountsEntity.setProductCode("SA101");
        accountsEntity.setCreatedAt(Instant.now().toString());

        accountsRepo.save(accountsEntity);

        System.out.println(accountsRepo.findBySortCodeAndAccountNumber(sortCode, accountNumber));

    }

    public void createNewCurrentAccount(){

        String sortCode = accountGenerator.generateSortCode();
        String accountNumber = accountGenerator.generateAccountNumber();
        while (accountsRepo.existsBySortCodeAndAccountNumber(sortCode, accountNumber))
        {
            sortCode = accountGenerator.generateSortCode();
            accountNumber = accountGenerator.generateAccountNumber();
        }
        AccountsEntity accountsEntity = new AccountsEntity();
        accountsEntity.setSortCode(sortCode);
        accountsEntity.setAccountNumber(accountNumber);
        accountsEntity.setAccountStatus("NEW");
        accountsEntity.setAccountState("ACTIVE");
        accountsEntity.setProductType("Current");
        accountsEntity.setProductCode("CA102");
        accountsEntity.setCreatedAt(Instant.now().toString());

        accountsRepo.save(accountsEntity);

        System.out.println(accountsRepo.findBySortCodeAndAccountNumber(sortCode, accountNumber));

    }

    public void validateAccountExist(){
        Boolean isAccountExist = accountsRepo.existsByProductTypeAndAccountStatusAndAccountState(
                "CURRENT",
                "NEW",
                "ACTIVE"
        );

        Assert.isTrue(isAccountExist);
    }

    @Test
    public void TestRunner(){
        for(int i = 0; i < 5; i++){
            createNewSavingsAccount();
            createNewCurrentAccount();
        }
//        validateAccountExist();
    }


}
