package com.example.ServiceC;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ServiceCApplicationTests {

	@Autowired
	MockMvc mockMvc;

	private static final String TOKEN_ENDPOINT = "/oauth2/token";

	@Test
	public void testAccessToken() throws Exception {

		mockMvc.perform(post(TOKEN_ENDPOINT)
						.param("grant_type", "client_credentials")
						.param("client_id", "0d5502ff-e723-4a02-a162-d17d63b10851")
						.param("client_secret", "034bbaba-2ae0-46ed-bc24-03643ea942d9")
						.param("scope", "read"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(result -> {
					System.out.println("Response Body: " +
							result.getResponse().getContentAsString());
				});
	}
}