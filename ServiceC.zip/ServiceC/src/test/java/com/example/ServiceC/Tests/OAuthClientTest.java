package com.example.ServiceC.Tests;


import com.example.ServiceC.Entity.OAuthClientEntity;
import com.example.ServiceC.Repository.OAuthClientRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Rollback;

import java.util.UUID;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class OAuthClientTest {

    @Autowired
    OAuthClientRepository oAuthClientRepository;


    public void testCreateOAuthClient1() {

        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        OAuthClientEntity oAuthClient = new OAuthClientEntity();
        oAuthClient.setClientId(UUID.randomUUID().toString());

        String clientSecret = UUID.randomUUID().toString();
        oAuthClient.setClientSecret(passwordEncoder.encode(clientSecret));
        oAuthClient.setGrantTypes("client_credentials");
        oAuthClient.setScopes("read");
        oAuthClient.setRedirectUri("http://localhost:9091/callback");

        System.out.println("ClientId: "+oAuthClient.getClientId());
        System.out.println("ClientSecret: "+clientSecret);
        oAuthClientRepository.save(oAuthClient);

    }

    public void testCreateOAuthClient2() {
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        OAuthClientEntity oAuthClient = new OAuthClientEntity();
        oAuthClient.setClientId(UUID.randomUUID().toString());
        String clientSecret = UUID.randomUUID().toString();
        oAuthClient.setClientSecret(passwordEncoder.encode(clientSecret));
        oAuthClient.setGrantTypes("authorization_code");
        oAuthClient.setScopes("openid");
        oAuthClient.setRedirectUri("http://localhost:9091/callback");

        System.out.println("ClientId: "+oAuthClient.getClientId());
        System.out.println("ClientSecret: "+clientSecret);
        oAuthClientRepository.save(oAuthClient);

    }

    @Test()
    public void Test(){
       for(int i=0;i<5;i++){
           testCreateOAuthClient1();
           testCreateOAuthClient2();
       }
    }
}
