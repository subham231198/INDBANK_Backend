package com.example.admin.ApplicationAdmin;


import com.example.admin.ApplicationAdmin.Entity.AdminAuthEntity;
import com.example.admin.ApplicationAdmin.Repository.AdminAuthRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
public class AdminServiceTest {

    @Autowired
    private AdminAuthRepo adminAuthRepo;


    @Test
    public void createAdmin(){

        List<String> locations = List.of(
                "KOLKATA",
                "HYDERABAD",
                "MUMBAI",
                "CHENNAI",
                "DELHI",
                "BANGALORE",
                "VARANASI",
                "BHUBANESHWAR",
                "VIZAG",
                "PUNE"
        );

        AdminAuthEntity adminAuthEntity = new AdminAuthEntity();
        adminAuthEntity.setAdminId(
                "ADM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()
        );
        adminAuthEntity.setPassword(UUID.randomUUID().toString());
        adminAuthEntity.setLocation(locations.get(
                ThreadLocalRandom.current().nextInt(locations.size())));
        adminAuthEntity.setIs_admin_locked(false);
        adminAuthEntity.setIs_admin_suspended(false);
        adminAuthEntity.setRole("CRO");
        adminAuthEntity.setInvalid_otp_attempt(0);
        adminAuthEntity.setInvalid_password_attempt(0);
        adminAuthEntity.setLast_successful_login("NA");
        adminAuthEntity.setLast_failed_login_attempt("NA");

        System.out.println("Username: "+adminAuthEntity.getAdminId());
        System.out.println("Password: "+adminAuthEntity.getPassword());
        adminAuthRepo.saveAndFlush(adminAuthEntity);
    }
}
