package com.example.admin.ApplicationAdmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class ApplicationAdminApplicationTests {


	@Test
	void contextLoads() {
	}

}
