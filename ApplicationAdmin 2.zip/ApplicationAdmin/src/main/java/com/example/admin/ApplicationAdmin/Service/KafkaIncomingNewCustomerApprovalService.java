package com.example.admin.ApplicationAdmin.Service;

import com.example.admin.ApplicationAdmin.Entity.CustomerApprovalQueue;
import com.example.admin.ApplicationAdmin.Repository.CustomerApprovalRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

@Service
public class KafkaIncomingNewCustomerApprovalService {

    @Autowired
    private CustomerApprovalRepo customerApprovalRepo;

    private KafkaTemplate<String, Objects> kafkaTemplate;

    private static final Logger logger = LogManager.getLogger(KafkaIncomingNewCustomerApprovalService.class);
    public void saveCustomerApprovalToDb(CustomerApprovalQueue customerApprovalQueue) {
        customerApprovalRepo.save(customerApprovalQueue);
    }


    @Autowired
    private ObjectMapper objectMapper;

    @KafkaListener(
            topics = "new-customer-registrations-bom-approval",
            groupId = "application-admin-group"
    )
    public void consumeAndSaveCustomerApproval(
            String message,
            Acknowledgment acknowledgment
            ) {

        try {

            Map<String, Object> payload =
                    objectMapper.readValue(message, Map.class);

            logger.info("Incoming message = {}", message);

            Map<String, Object> customer =
                    (Map<String, Object>) payload.get("customer");

            Map<String, Object> occupation = (Map<String, Object>) payload.get("occupation");

            String location = (String) payload.get("location");

            Map<String, Object> account =
                    (Map<String, Object>) payload.get("account");

            CustomerApprovalQueue queue =
                    new CustomerApprovalQueue();

            queue.setCustomerId(
                    (String) payload.get("customerId")
            );

            queue.setFirst_name(
                    (String) customer.get("first_name")
            );

            queue.setLast_name(
                    (String) customer.get("last_name")
            );

            queue.setEmail(
                    (String) customer.get("email")
            );

            queue.setPhoneNumber(
                    (String) customer.get("contact")
            );

            queue.setAccountType(
                    (String) account.get("account_type")
            );

            queue.setStatus("PENDING");

            if(Double.parseDouble(occupation.get("annual_income").toString())>1000000000.00) {
                queue.setRisk_rank("HIGH PLUS");
            }

            else if(Double.parseDouble(occupation.get("annual_income").toString())>500000000.00 && Integer.parseInt(occupation.get("annual_income").toString())<=1000000000.00) {
                queue.setRisk_rank("HIGH RISK");
            }

            else {
                queue.setRisk_rank("NORMAL");
            }

            queue.setIs_kyc_completed(false);

            queue.setIs_edd_required(false);

            queue.setReviewedAt("NA");

            queue.setApprovedAt("NA");

            queue.setCity(location);

            queue.setIsFlaggedForManualReview(false);

            queue.setApprovalLevel("Pending BOM");

            queue.setSubmittedAt(
                    java.time.Instant.now().toString()
            );

            customerApprovalRepo.save(queue);
            acknowledgment.acknowledge();

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to process customer approval message",
                    e
            );
        }
    }
}
