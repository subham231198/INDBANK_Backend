package com.example.admin.ApplicationAdmin.Exception;

public class NoCustomerIdException extends RuntimeException {
    public NoCustomerIdException(String message) {
        super(message);
    }
}
