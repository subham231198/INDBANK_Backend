package com.example.admin.ApplicationAdmin.Exception;

public class KYCNotVerifiedException extends RuntimeException {
    public KYCNotVerifiedException(String message) {
        super(message);
    }
}
