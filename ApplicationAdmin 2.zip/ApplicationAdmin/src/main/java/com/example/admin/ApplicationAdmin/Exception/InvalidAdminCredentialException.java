package com.example.admin.ApplicationAdmin.Exception;

public class InvalidAdminCredentialException extends RuntimeException {
    public InvalidAdminCredentialException(String message) {
        super(message);
    }
}
