package com.example.admin.ApplicationAdmin.Repository;

import com.example.admin.ApplicationAdmin.Entity.AdminSessionAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminAuditRepo extends JpaRepository<AdminSessionAudit, Long> {
    Optional<AdminSessionAudit> findByAdminSessionId(String adminSessionId);
}
