package com.example.admin.ApplicationAdmin.Service;


import com.example.admin.ApplicationAdmin.DTO.AdminSessionDTO;
import com.example.admin.ApplicationAdmin.Entity.AdminAuthEntity;
import com.example.admin.ApplicationAdmin.Entity.AdminSessionAudit;
import com.example.admin.ApplicationAdmin.Exception.AdminNotFoundException;
import com.example.admin.ApplicationAdmin.Exception.InvalidAdminCredentialException;
import com.example.admin.ApplicationAdmin.Exception.InvalidAdminSessionException;
import com.example.admin.ApplicationAdmin.Repository.AdminAuditRepo;
import com.example.admin.ApplicationAdmin.Repository.AdminAuthRepo;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AdminAuthenticationService {

    @Autowired
    private AdminAuthRepo adminAuthRepo;

    @Autowired
    private OTPService otpService;

    @Autowired
    private AdminAuditRepo adminAuditRepo;

    @Autowired
    private AdminSessionService adminSessionService;

    public ResponseEntity<?> adminAuthentication(
            String adminId,
            String password,
            String otp,
            String correlationId,
            HttpServletResponse http_response
    ){
        Optional<AdminAuthEntity> admin_optional = adminAuthRepo.findByAdminId(adminId);
        AdminAuthEntity adminAuthEntity = admin_optional.get();

        if(!admin_optional.isPresent()){
            throw new AdminNotFoundException("Admin not found by adminId");
        }

        if(adminAuthEntity.getIs_admin_locked()){
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Profile locked!"
            );
        }

        if(adminAuthEntity.getIs_admin_suspended()){
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Profile suspended!"
            );
        }

        if(!adminAuthRepo.existsByAdminIdAndPassword(adminId, password)){
            if(adminAuthEntity.getInvalid_password_attempt()==5){
                adminAuthEntity.setIs_admin_locked(true);
                adminAuthRepo.save(adminAuthEntity);
                throw new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Profile locked due to too many invalid password attempts!"
                );
            }
            adminAuthEntity.setInvalid_password_attempt(adminAuthEntity.getInvalid_password_attempt()+1);
            throw new InvalidAdminCredentialException("Invalid admin auth credentials");
        }

        Boolean otpValid = otpService.validateOTP(adminId, otp);
        if(!otpValid){
            if(adminAuthEntity.getInvalid_otp_attempt()==5){
                adminAuthEntity.setIs_admin_locked(true);
                adminAuthRepo.save(adminAuthEntity);
                throw new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Profile locked due to too many invalid otp attempts!"
                );
            }
            adminAuthEntity.setInvalid_otp_attempt(adminAuthEntity.getInvalid_otp_attempt()+1);
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Invalid otp"
            );
        }


        String adminSession = String.valueOf(UUID.randomUUID()) + UUID.randomUUID() + "==";
        Long issuedAt = Instant.now().toEpochMilli();
        Long expiry = Instant.now().plusSeconds(600).toEpochMilli();
        String authLevel = "30";

        AdminSessionDTO adminSessionDTO = new AdminSessionDTO();
        adminSessionDTO.setAdminId(adminId);
        adminSessionDTO.setAdminSession(adminSession);
        adminSessionDTO.setCorrelationId(correlationId);
        adminSessionDTO.setAuth_level(authLevel);
        adminSessionDTO.setIssuedAt(issuedAt);
        adminSessionDTO.setExpiry(expiry);

        adminSessionService.createSession(adminSessionDTO);

        Map<String, Object> response = new ConcurrentHashMap<>();
        response.put("tokenId", adminSession);
        response.put("role", "./admin");

        ResponseCookie cookie =
                ResponseCookie.from("ADMIN_SESSION", adminSession)
                        .httpOnly(true)
                        .secure(true)
                        .sameSite("Strict")
                        .path("/")
                        .maxAge(Duration.ofMinutes(10))
                        .build();


        http_response.addHeader(
                HttpHeaders.SET_COOKIE,
                cookie.toString()
        );

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public Map<String, Object> getSessionInfo(String sessionId){
        AdminSessionDTO session = Optional
                .ofNullable(adminSessionService.getSession(sessionId))
                .orElseThrow(()-> new InvalidAdminSessionException("Invalid session provided! "+sessionId));
        Long issuedAt = session.getIssuedAt();
        Long expiry = session.getExpiry();

        if(session.getAdminId()==null || session.getAdminId().isEmpty() || Instant.now().toEpochMilli()>expiry){
            return Map.of("valid", false);
        }
        Optional<AdminAuthEntity> admin = adminAuthRepo.findByAdminId(session.getAdminId());
        if(!admin.isPresent()){
            throw new AdminNotFoundException("AdminId is invalid!");
        }

        Map<String, Object> response = new ConcurrentHashMap<>();
        response.put("isSessionValid", true);
        response.put("admin", admin.get().getAdminId());
        response.put("role", admin.get().getRole());
        response.put("correlationId", session.getCorrelationId());
        response.put("location", admin.get().getLocation());
        response.put("issuedAt", issuedAt);
        response.put("expiry", expiry);

        return response;
    }

    public Boolean keepAlive(String sessionId){
        AdminSessionDTO session = Optional
                .ofNullable(adminSessionService.getSession(sessionId))
                .orElseThrow(()-> new InvalidAdminSessionException("Invalid session provided! "+sessionId));
        Long expiry = session.getExpiry();

        if(Instant.now().toEpochMilli() > expiry){
            return false;
        }
        return true;
    }

    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> logOffProvider(String sessionId){
        try {
            Boolean isSessionValid = keepAlive(sessionId);

            if (!isSessionValid) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Error resolving user from JSON");
            }
        }
        catch (InvalidAdminSessionException ex){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Error resolving user from JSON");
        }

        AdminSessionDTO session = Optional
                .ofNullable(adminSessionService.getSession(sessionId))
                .orElseThrow(()-> new InvalidAdminSessionException("Invalid session provided! "+sessionId));
        String adminId = session.getAdminId();
        String correlationId = session.getCorrelationId();
        Long issuedAt = session.getIssuedAt();

        AdminSessionAudit adminSessionAudit = new AdminSessionAudit();
        adminSessionAudit.setAdminId(adminId);
        adminSessionAudit.setAdminSessionId(sessionId);
        adminSessionAudit.setSessionCorrelationId(correlationId);
        adminSessionAudit.setLoggedInTimeStamp(String.valueOf(issuedAt));
        adminSessionAudit.setLoggedOutTimeStamp(String.valueOf(Instant.now().toEpochMilli()));
        adminSessionService.invalidateSession(sessionId);
        adminAuditRepo.save(adminSessionAudit);
        return Map.of("message", "Successfully logged out of all sessions.");
    }
}
