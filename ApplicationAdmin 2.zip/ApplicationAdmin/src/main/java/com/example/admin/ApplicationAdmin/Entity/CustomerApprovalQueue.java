package com.example.admin.ApplicationAdmin.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customer_approval_queue")
public class CustomerApprovalQueue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long queue_id;

    @Column(name = "customer_id", nullable = false)
    private String customerId;

    @Column(name = "first_name")
    private String first_name;

    @Column(name = "last_name")
    private String last_name;

    @Column(name = "email")
    private String email;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "account_type")
    private String accountType;

    @Column(name = "status")
    private String status;

    @Column(name = "city")
    private String city;

    @Column(name = "risk_rank")
    private String risk_rank;

    @Column(name = "is_kyc_completed")
    private Boolean is_kyc_completed;

    @Column(name = "is_edd_required")
    private Boolean is_edd_required;

    @Column(name = "is_flagged_for_manual_review")
    private Boolean isFlaggedForManualReview;

    @Column(name = "approval_level")
    private String approvalLevel;

    @Column(name = "submitted_at")
    private String submittedAt;

    @Column(name = "reviewed_at")
    private String reviewedAt;

    @Column(name = "approved_at")
    private String approvedAt;
}
