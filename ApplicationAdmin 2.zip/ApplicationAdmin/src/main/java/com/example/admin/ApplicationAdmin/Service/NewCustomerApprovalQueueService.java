package com.example.admin.ApplicationAdmin.Service;

import com.example.admin.ApplicationAdmin.Entity.ApprovedAccounts;
import com.example.admin.ApplicationAdmin.Entity.CustomerApprovalQueue;
import com.example.admin.ApplicationAdmin.Exception.NoCustomerIdException;
import com.example.admin.ApplicationAdmin.Repository.ApprovalRepo;
import com.example.admin.ApplicationAdmin.Repository.CustomerApprovalRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@Service
public class NewCustomerApprovalQueueService {

    @Autowired
    private CustomerApprovalRepo customerApprovalRepo;

    @Autowired
    private ApprovalRepo approvalRepo;

    @Autowired
    private AdminAuthenticationService adminAuthenticationService;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    public ResponseEntity<?> getCustomerDetails(String adminSession, String customerId) {
        String location = getLocationFromSession(adminSession);
        CustomerApprovalQueue customer = customerApprovalRepo
                .findByCustomerIdAndCity(customerId, location)
                .orElseThrow(() -> new NoCustomerIdException("Customer details not found!"));

        customer.setReviewedAt(Instant.now().toString());
        log.info("CustomerId: {} reviewed at {} by admin: {}", customerId, customer.getReviewedAt(), getAdminIdFromSession(adminSession));
        customerApprovalRepo.save(customer);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("customerId", customer.getCustomerId());
        response.put("first_name", customer.getFirst_name());
        response.put("last_name", customer.getLast_name());
        response.put("email", customer.getEmail());
        response.put("phoneNumber", customer.getPhoneNumber());
        response.put("accountType", customer.getAccountType());
        response.put("status", customer.getStatus());
        response.put("city", customer.getCity());
        response.put("risk_rank", customer.getRisk_rank());
        response.put("is_kyc_completed", customer.getIs_kyc_completed());
        response.put("is_edd_required", customer.getIs_edd_required());
        response.put("isFlaggedForManualReview", customer.getIsFlaggedForManualReview());
        response.put("approvalLevel", customer.getApprovalLevel());
        response.put("submittedAt", customer.getSubmittedAt());
        response.put("reviewedAt", customer.getReviewedAt());
        response.put("approvedAt", customer.getApprovedAt());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllPendingApprovalCustomers(String sessionId) {
        String location = getLocationFromSession(sessionId);
        return new ResponseEntity<>(customerApprovalRepo.findByCity(location), HttpStatus.OK);
    }

    public String getAdminIdFromSession(String adminSession){
        Map<String, Object> session_details = adminAuthenticationService.getSessionInfo(adminSession);
        return session_details.get("admin").toString();
    }

    public ResponseEntity<?> performActionBOM(String sessionId, String customerId, String action) {
        Map<String, Object> adminDetails = validateSession(sessionId);
        CustomerApprovalQueue customer = customerApprovalRepo
                .findByCustomerIdAndCity(customerId, adminDetails.get("location").toString())
                .orElseThrow(() -> new NoCustomerIdException("Customer details not found!"));

        validateActionPermissions(customer, adminDetails.get("role").toString());

        String timestamp = Instant.now().toString();
        customer.setReviewedAt(timestamp);
        customer.setApprovalLevel(adminDetails.get("role").toString());

        if (action.equalsIgnoreCase("APPROVE")) {
            if (customer.getStatus().equals("APPROVED")) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Already approved customer");
            }
            customer.setStatus("APPROVED");
            saveApprovedAccount(adminDetails.get("admin").toString(), customerId, timestamp);
            kafkaTemplate.send("customer-bom-approved-normal", customerId);
        } else if (action.equalsIgnoreCase("REJECT")) {
            customer.setStatus("REJECTED");
            kafkaTemplate.send("customer-bom-rejected-normal", customerId);
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid action provided!");
        }

        customerApprovalRepo.save(customer);
        return new ResponseEntity<>(Map.of("message", "Successfully " + action.toLowerCase() + " customerId: " + customerId), HttpStatus.CREATED);
    }

    public Map<String, Object> validateSession(String adminSession) {
        if (!adminAuthenticationService.keepAlive(adminSession)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Access Denied!");
        }
        return adminAuthenticationService.getSessionInfo(adminSession);
    }

    private String getLocationFromSession(String sessionId) {
        return validateSession(sessionId).get("location").toString();
    }

    private void validateActionPermissions(CustomerApprovalQueue customer, String role) {
        if (!customer.getRisk_rank().equals("NORMAL") && role.equals("BOM")) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "EDD Triggered Accounts require higher level scrutiny");
        }
        if (!customer.getIs_kyc_completed()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Cannot approve account without Kyc");
        }
    }

    private void saveApprovedAccount(String adminId, String customerId, String timestamp) {
        ApprovedAccounts approved = new ApprovedAccounts();
        approved.setAdminId(adminId);
        approved.setCustomerId(customerId);
        approved.setApprovedAt(timestamp);
        approvalRepo.save(approved);
    }
}