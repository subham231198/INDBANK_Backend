package com.example.admin.ApplicationAdmin.Service;

import com.example.admin.ApplicationAdmin.DTO.OTPServiceDTO;
import com.example.admin.ApplicationAdmin.Exception.AdminNotFoundException;
import com.example.admin.ApplicationAdmin.Exception.InvalidAdminCredentialException;
import com.example.admin.ApplicationAdmin.Repository.AdminAuthRepo;
import com.example.admin.ApplicationAdmin.Utility.Generator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.util.Map;

@Service
public class OTPService {

    @Autowired
    private AdminAuthRepo adminAuthRepo;

    @Autowired
    private Generator generator;

    @Autowired
    private AdminOTPCacheService adminOTPCacheService;

    private static final Logger logger = LogManager.getLogger(OTPService.class);


    public ResponseEntity<?> generateOTP(
            String adminId,
            String password) {

        if (adminId == null || adminId.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "AdminId cannot be empty");
        }

        if (password == null || password.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Password cannot be empty");
        }

        boolean exists =
                adminAuthRepo.existsByAdminIdAndPassword(
                        adminId,
                        password
                );

        if (!exists) {
            throw new InvalidAdminCredentialException(
                    "Invalid credentials"
            );
        }

        OTPServiceDTO existingOtp = adminOTPCacheService.getOTP(adminId);

        if (existingOtp != null &&
                Instant.now().isBefore(existingOtp.expiry())) {

            return ResponseEntity.ok(
                    Map.of(
                            "otp", existingOtp.otp(),
                            "expiresAt", existingOtp.expiry()
                    )
            );
        }

        String otp = generator.GenerateOTP();

        OTPServiceDTO otpServiceDTO =
                new OTPServiceDTO(
                        adminId,
                        otp,
                        Instant.now(),
                        Instant.now().plusSeconds(60)
                );

        adminOTPCacheService.createOTP(otpServiceDTO);

        return ResponseEntity.ok(
                Map.of(
                        "otp", otp,
                        "expiresAt", otpServiceDTO.expiry()
                )
        );
    }

    public boolean validateOTP(
            String adminId,
            String otp) {

        if (adminId == null || adminId.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "AdminId cannot be empty"
            );
        }

        if (otp == null || otp.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "OTP cannot be empty"
            );
        }

        if (!adminAuthRepo.existsById(adminId)) {
            throw new AdminNotFoundException(
                    "Admin not found"
            );
        }

        OTPServiceDTO cachedOtp = adminOTPCacheService.getOTP(adminId);

        if (cachedOtp == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "OTP not generated"
            );
        }

        if (Instant.now().isAfter(cachedOtp.expiry())) {

            adminOTPCacheService.invalidateOTP(adminId);

            return false;
        }

        if (!cachedOtp.otp().equals(otp)) {
            return false;
        }

        adminOTPCacheService.invalidateOTP(adminId);

        return true;
    }


}