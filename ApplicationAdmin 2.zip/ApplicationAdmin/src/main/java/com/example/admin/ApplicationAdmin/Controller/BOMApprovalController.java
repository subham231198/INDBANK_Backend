package com.example.admin.ApplicationAdmin.Controller;

import com.example.admin.ApplicationAdmin.DTO.SessionAttributes;
import com.example.admin.ApplicationAdmin.Service.NewCustomerApprovalQueueService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@Tag(name = "BOM Approval Controller", description = "Endpoints for managing BOM (Bill of Materials) approval processes")
public class BOMApprovalController {

    private static final String ACCESS_DENIED = "Access Denied";
    private static final String HEADER_MISSING = "Header missing!";
    private static final String WEB_CHANNEL = "WEB";
    private static final String EVALUATE_ACTION = "evaluate";

    @Autowired
    private NewCustomerApprovalQueueService newCustomerApprovalQueueService;

    @Operation(
            summary = "Approve customer profile BOM",
            description = "Approves the profile BOM for a specific customer. Requires admin authentication and channel validation."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Profile BOM approved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input parameters"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid channel or authentication")
    })
    @PostMapping(
            value = "api/v1/approve-profile-bom/customer/{customerId}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE,
            headers = {"X-Channel", "adminSessionId"}
    )
    public ResponseEntity<?> approveProfileBom(
            @Parameter(description = "Customer ID for profile BOM approval", required = true, example = "CUST12345")
            @PathVariable("customerId") String customerId,

            @Parameter(description = "Request source channel (mobile, web, branch)", required = true, example = "MOBILE")
            @RequestHeader(value = "X-Channel") String channel,

            @Parameter(description = "Admin session ID for authentication", required = true, example = "sess_67890")
            @RequestHeader(value = "adminSessionId") String adminSessionId
    ) {
        validateCustomerId(customerId);
        validateAdminSessionId(adminSessionId);
        validateChannelPresence(channel);
        validateWebChannelAccess(channel);

        return newCustomerApprovalQueueService.performActionBOM(adminSessionId, customerId, "APPROVE");
    }

    @Operation(
            summary = "Get all pending approval customers",
            description = "Retrieves all customers pending approval. Requires admin authentication and web channel access."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pending approvals retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid action, channel, or authentication")
    })
    @PostMapping(
            value = "/api/v1/admin/approval/pending/all",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<?> getAllPendingApproval(
            @Parameter(description = "Action to perform (must be 'evaluate')", required = true, example = "evaluate")
            @RequestParam(value = "_action") String action,

            @Parameter(description = "Request source channel (must be WEB)", required = true, example = "WEB")
            @RequestHeader(value = "X-Channel") String channel,

            @Parameter(description = "Admin session token for authentication", required = true, example = "sess_67890")
            @RequestHeader(value = "adminSession") String adminSession,

            @Parameter(description = "Session attributes containing token ID", required = true)
            @RequestBody SessionAttributes sessionAttributes
    ) {
        validateAction(action);
        validateChannelPresence(channel);
        validateNonWebChannelAccess(channel);
        validateTokenId(sessionAttributes);
        validateSessionMatching(adminSession, sessionAttributes);

        return newCustomerApprovalQueueService.getAllPendingApprovalCustomers(sessionAttributes.getTokenId());
    }


    @Operation(
            summary = "Review pending approval customers one at a time",
            description = "Retrieves a customer who is pending approval. Requires admin authentication and web channel access."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pending approvals retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid action, channel, or authentication")
    })
    @PostMapping(
            value = "api/v1/admin/review",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<?> reviewPipelinedCustomer(
            @Parameter(description = "Action to perform (must be 'evaluate')", required = true, example = "evaluate")
            @RequestParam(value = "_action") String action,

            @Parameter(description = "Action to perform (must be 'customerId')", required = true, example = "customerId")
            @RequestParam(value = "customerId") String customerId,

            @Parameter(description = "Request source channel (must be WEB)", required = true, example = "WEB")
            @RequestHeader(value = "X-Channel") String channel,

            @Parameter(description = "Admin session token for authentication", required = true, example = "sess_67890")
            @RequestHeader(value = "adminSession") String adminSession,

            @Parameter(description = "Session attributes containing token ID", required = true)
            @RequestBody SessionAttributes sessionAttributes
    ){
        validateAction(action);
        validateChannelPresence(channel);
        validateCustomerId(customerId);
        validateNonWebChannelAccess(channel);
        validateTokenId(sessionAttributes);
        validateSessionMatching(adminSession, sessionAttributes);
        return newCustomerApprovalQueueService.getCustomerDetails(adminSession, customerId);
    }



    private void validateCustomerId(String customerId) {
        if (isNullOrEmpty(customerId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "customerId cannot be null or blank!");
        }
    }

    private void validateAdminSessionId(String adminSessionId) {
        if (isNullOrEmpty(adminSessionId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "adminSessionId cannot be null or blank!");
        }
    }

    private void validateChannelPresence(String channel) {
        if (isNullOrEmpty(channel)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, HEADER_MISSING);
        }
    }

    private void validateWebChannelAccess(String channel) {
        if (WEB_CHANNEL.equalsIgnoreCase(channel)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private void validateNonWebChannelAccess(String channel) {
        if (!WEB_CHANNEL.equalsIgnoreCase(channel)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private void validateAction(String action) {
        if (!EVALUATE_ACTION.equals(action)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private void validateTokenId(SessionAttributes sessionAttributes) {
        if (sessionAttributes.getTokenId() == null || sessionAttributes.getTokenId().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "tokenId cannot be null or blank");
        }
    }

    private void validateSessionMatching(String adminSession, SessionAttributes sessionAttributes) {
        if (!adminSession.equals(sessionAttributes.getTokenId())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
}