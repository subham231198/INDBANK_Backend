package com.example.admin.ApplicationAdmin;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.kafka.annotation.EnableKafka;

@Slf4j
@SpringBootApplication
@EnableCaching
@EnableKafka
public class ApplicationAdminApplication {

	private static final Logger logger = LogManager.getLogger(ApplicationAdminApplication.class);

	public static void main(String[] args) {

		logger.info("Starting application_admin app.......");
		SpringApplication.run(ApplicationAdminApplication.class, args);
		logger.info("Application started successfully!");
	}

}
