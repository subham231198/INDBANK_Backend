package com.example.admin.ApplicationAdmin.DTO;


import java.time.Instant;

public record OTPServiceDTO(
        String adminId,

        String otp,

        Instant issuedAt,

        Instant expiry
) {
}
