package com.example.admin.ApplicationAdmin.DTO;

public record CallbackItem(
        String name,
        String value
) {
}
