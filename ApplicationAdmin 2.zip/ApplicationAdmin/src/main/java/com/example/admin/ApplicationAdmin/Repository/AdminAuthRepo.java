package com.example.admin.ApplicationAdmin.Repository;

import com.example.admin.ApplicationAdmin.Entity.AdminAuthEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.Optional;

@Repository
public interface AdminAuthRepo extends JpaRepository<AdminAuthEntity, String> {

    Optional<AdminAuthEntity> findByAdminId(String adminId);

    Boolean existsByAdminIdAndPassword(String adminId, String password);
}
