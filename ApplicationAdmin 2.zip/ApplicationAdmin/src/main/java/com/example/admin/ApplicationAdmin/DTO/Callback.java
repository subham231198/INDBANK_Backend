package com.example.admin.ApplicationAdmin.DTO;

public record Callback(
        CallbackItem nameCallback,
        CallbackItem passwordCallback,
        CallbackItem otpCallback
) {

}

