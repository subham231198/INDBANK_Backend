package com.example.admin.ApplicationAdmin.Exception;

public class InvalidAdminSessionException extends RuntimeException {
  public InvalidAdminSessionException(String message) {
    super(message);
  }
}
