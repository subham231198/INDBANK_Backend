package com.example.admin.ApplicationAdmin.Entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "admin_auth_table")
public class AdminAuthEntity {

    @Id
    private String adminId;

    private String password;

    private String role;

    private String location;

    private Boolean is_admin_suspended;

    private Boolean is_admin_locked;

    private Integer invalid_password_attempt;

    private Integer invalid_otp_attempt;

    private String last_successful_login;

    private String last_failed_login_attempt;
}
