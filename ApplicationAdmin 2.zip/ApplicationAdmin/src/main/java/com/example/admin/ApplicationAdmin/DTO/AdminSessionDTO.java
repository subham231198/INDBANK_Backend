package com.example.admin.ApplicationAdmin.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminSessionDTO {

    private String adminId;

    private String adminSession;

    private String correlationId;

    private Long issuedAt;

    private Long expiry;

    private String auth_level;
}
