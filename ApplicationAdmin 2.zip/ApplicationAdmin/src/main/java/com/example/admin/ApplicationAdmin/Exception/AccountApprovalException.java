package com.example.admin.ApplicationAdmin.Exception;

public class AccountApprovalException extends RuntimeException {
  public AccountApprovalException(String message) {
    super(message);
  }
}
