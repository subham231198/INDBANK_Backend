package com.example.admin.ApplicationAdmin.Service;

import com.example.admin.ApplicationAdmin.DTO.OTPServiceDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class AdminOTPCacheService {

    private static final Logger logger = LogManager.getLogger(AdminOTPCacheService.class);

    @CachePut(
            value = "otpService",
            key = "#otpServiceDTO.adminId()"
    )
    public OTPServiceDTO createOTP(
            OTPServiceDTO otpServiceDTO) {

        logger.info("OTP Service created for "+otpServiceDTO.adminId());
        return otpServiceDTO;
    }

    @Cacheable(
            value = "otpService",
            key = "#adminId"
    )
    public OTPServiceDTO getOTP(
            String adminId) {

        return null;
    }

    @CacheEvict(
            value = "otpService",
            key = "#adminId"
    )
    public void invalidateOTP(
            String adminId) {
    }
}
