package com.example.admin.ApplicationAdmin.Exception;

public class AccountNotAvailableException extends RuntimeException {
  public AccountNotAvailableException(String message) {
    super(message);
  }
}
