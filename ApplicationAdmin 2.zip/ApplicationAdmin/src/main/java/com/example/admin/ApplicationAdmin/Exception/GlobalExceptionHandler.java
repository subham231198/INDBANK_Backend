package com.example.admin.ApplicationAdmin.Exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    Map<String, Object> response = new LinkedHashMap<>();

    @ExceptionHandler(AdminNotFoundException.class)
    public ResponseEntity<?> AdminNotFound(Exception ex){
        response.put("code", 404);
        response.put("reason", "Not Found");
        response.put("message", "Admin not found");

        return new ResponseEntity<>(response, HttpStatusCode.valueOf(404));
    }

    @ExceptionHandler(InvalidAdminCredentialException.class)
    public ResponseEntity<?> InvalidAdminCredentials(Exception ex){
        response.put("code", 401);
        response.put("reason", "Unauthorized");
        response.put("message", "Invalid credentials");

        return new ResponseEntity<>(response, HttpStatusCode.valueOf(401));
    }

    @ExceptionHandler(InvalidAdminSessionException.class)
    public ResponseEntity<?> InvalidAdminSessionException(Exception ex){
        response.put("isSessionValid", false);

        return new ResponseEntity<>(response, HttpStatusCode.valueOf(200));
    }

    @ExceptionHandler(KYCNotVerifiedException.class)
    public ResponseEntity<?> KycNotVerified(Exception ex){
        response.put("code", 401);
        response.put("reason", "Unauthorized");
        response.put("message", "Access Denied");

        log.info(response.toString());
        return new ResponseEntity<>(response, HttpStatusCode.valueOf(401));
    }

    @ExceptionHandler(NoCustomerIdException.class)
    public ResponseEntity<?> NoCustomerException(Exception ex){
        response.put("code", 401);
        response.put("reason", "Unauthorized");
        response.put("message", "Customer not found by customerId");

        log.info(response.toString());
        return new ResponseEntity<>(response, HttpStatusCode.valueOf(401));
    }

    @ExceptionHandler(AccountApprovalException.class)
    public ResponseEntity<?> AccountApprovalException(Exception ex){
        response.put("code", 401);
        response.put("reason", "Unauthorized");
        response.put("message", "Error in approving account");

        log.info(response.toString());
        return new ResponseEntity<>(response, HttpStatusCode.valueOf(401));
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<?> handleResponseStatus(
            ResponseStatusException ex
    ) {

        String reason = switch (ex.getStatusCode().value()) {

            case 400 -> "Bad Request";

            case 401 -> "Unauthorized";

            case 403 -> "Forbidden";

            case 404 -> "Not Found";

            case 500 -> "Internal Server Error";

            default -> "Unexpected Error";
        };

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("code", ex.getStatusCode().value());
        response.put("reason", reason);
        response.put("message", ex.getReason());

        log.info(response.toString());
        return new ResponseEntity<>(
                response,
                ex.getStatusCode()
        );
    }

}
