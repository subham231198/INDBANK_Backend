package com.example.admin.ApplicationAdmin.Utility;

import org.springframework.stereotype.Component;

@Component
public class Generator {

    public String GenerateOTP()
    {
        String otp = String.valueOf((int)(Math.random() * 900000) + 100000);
        return otp;
    }
}
