package com.example.admin.ApplicationAdmin.Controller;

import com.example.admin.ApplicationAdmin.DTO.SessionAttributes;
import com.example.admin.ApplicationAdmin.Service.AdminAuthenticationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@Tag(name = "Admin Session Controller", description = "Endpoints for managing admin sessions, retrieving session info, and logout")
public class AdminSessionController {

    private static final String ACCESS_DENIED = "Access Denied";
    private static final String WEB_CHANNEL = "WEB";
    private static final String GET_SESSION_ACTION = "getAdminSessionInfo";
    private static final String LOGOUT_ACTION = "translate";
    private static final String TOKEN_TYPE_SSO = "SSOTOKEN";
    private static final String BEARER_CONFIRMATION = "Bearer";

    @Autowired
    private AdminAuthenticationService adminSessionService;

    @Operation(
            summary = "Get admin session information",
            description = "Retrieves session information for an authenticated admin user"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Session information retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Missing or invalid headers"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid action, session mismatch, or channel"),
            @ApiResponse(responseCode = "403", description = "Missing required query parameters")
    })
    @PostMapping(
            value = "/v1/api/admin/session",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<?> getSessionAttributes(
            @Parameter(description = "Action to perform (must be 'getAdminSessionInfo')", required = true, example = "getAdminSessionInfo")
            @RequestParam(value = "_action") String action,

            @Parameter(description = "Request source channel (must be WEB)", required = true, example = "WEB")
            @RequestHeader(value = "X-Channel") String channel,

            @Parameter(description = "Admin session ID for authentication", required = true, example = "sess_67890")
            @RequestHeader(value = "adminSession") String adminSessionId,

            @Parameter(description = "Session attributes containing token ID", required = true)
            @RequestBody SessionAttributes sessionAttributes
    ) {
        validateAction(action);
        validateChannel(channel);
        validateSessionAccess(action, adminSessionId, channel, sessionAttributes);

        return new ResponseEntity<>(
                adminSessionService.getSessionInfo(sessionAttributes.getTokenId()),
                HttpStatus.OK
        );
    }

    @Operation(
            summary = "Admin logout",
            description = "Logs out an admin user by invalidating their SSO token"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Logout successful"),
            @ApiResponse(responseCode = "400", description = "Missing or invalid token state fields"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid action or token validation failed")
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            required = true,
            description = "Request body containing input and output token state",
            content = @Content(
                    examples = @ExampleObject(
                            name = "logout-example",
                            value = """
                {
                    "input_token_state": {
                        "token_type": "SSOTOKEN",
                        "tokenId": ""
                    },
                    "output_token_state": {
                        "token_type": "",
                        "subject_confirmation": "Bearer"
                    }
                }
                """
                    )
            )
    )
    @PostMapping(
            value = "/api/v1/rest-sts/logout",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<?> logout(
            HttpServletRequest httpServletRequest,

            @Parameter(description = "Action to perform (must be 'translate')", required = true, example = "translate")
            @RequestParam("_action") String action
    ) throws IOException {
        validateLogoutAction(action);

        String requestBody = extractRequestBody(httpServletRequest);
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> payload = mapper.readValue(requestBody, Map.class);

        Map<String, Object> inputTokenState = extractInputTokenState(payload);
        Map<String, Object> outputTokenState = extractOutputTokenState(payload);

        String tokenType = extractTokenType(inputTokenState);
        String outputTokenType = extractOutputTokenType(outputTokenState);
        String subjectConfirmation = extractSubjectConfirmation(outputTokenState);
        String tokenId = extractTokenId(inputTokenState);

        validateTokenStateFields(inputTokenState, outputTokenState);
        validateTokenFields(tokenType, tokenId, subjectConfirmation);
        validateOutputTokenType(outputTokenType);
        validateTokenCredentials(tokenType, subjectConfirmation);

        return new ResponseEntity<>(adminSessionService.logOffProvider(tokenId), HttpStatus.OK);
    }

    private void validateAction(String action) {
        if (isNullOrEmpty(action)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "missing query param");
        }
    }

    private void validateChannel(String channel) {
        if (isNullOrEmpty(channel)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "X-Channel header missing");
        }
    }

    private void validateSessionAccess(String action, String adminSessionId, String channel, SessionAttributes sessionAttributes) {
        boolean isInvalidAction = !GET_SESSION_ACTION.equals(action);
        boolean isSessionMismatch = !adminSessionId.equals(sessionAttributes.getTokenId());
        boolean isInvalidChannel = !WEB_CHANNEL.equalsIgnoreCase(channel);

        if (isInvalidAction || isSessionMismatch || isInvalidChannel) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private void validateLogoutAction(String action) {
        if (!LOGOUT_ACTION.equals(action)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private String extractRequestBody(HttpServletRequest request) throws IOException {
        return request.getReader().lines().collect(Collectors.joining());
    }

    private Map<String, Object> extractInputTokenState(Map<String, Object> payload) {
        return (Map<String, Object>) payload.get("input_token_state");
    }

    private Map<String, Object> extractOutputTokenState(Map<String, Object> payload) {
        return (Map<String, Object>) payload.get("output_token_state");
    }

    private String extractTokenType(Map<String, Object> inputTokenState) {
        return (String) inputTokenState.get("token_type");
    }

    private String extractOutputTokenType(Map<String, Object> outputTokenState) {
        return (String) outputTokenState.get("token_type");
    }

    private String extractSubjectConfirmation(Map<String, Object> outputTokenState) {
        return (String) outputTokenState.get("subject_confirmation");
    }

    private String extractTokenId(Map<String, Object> inputTokenState) {
        return (String) inputTokenState.get("tokenId");
    }

    private void validateTokenStateFields(Map<String, Object> inputTokenState, Map<String, Object> outputTokenState) {
        if (inputTokenState == null || inputTokenState.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "input_token_state cannot be null or blank");
        }
        if (outputTokenState == null || outputTokenState.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "output_token_state cannot be null or blank");
        }
    }

    private void validateTokenFields(String tokenType, String tokenId, String subjectConfirmation) {
        if (isNullOrEmpty(tokenType)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "token_type cannot be null or blank");
        }
        if (isNullOrEmpty(tokenId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "tokenId cannot be null or blank");
        }
        if (isNullOrEmpty(subjectConfirmation)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "subject_confirmation cannot be null or blank");
        }
    }

    private void validateOutputTokenType(String outputTokenType) {
        if (outputTokenType != null && !outputTokenType.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid value provided against output_token_type");
        }
    }

    private void validateTokenCredentials(String tokenType, String subjectConfirmation) {
        boolean isInvalidTokenType = !TOKEN_TYPE_SSO.equals(tokenType);
        boolean isInvalidConfirmation = !BEARER_CONFIRMATION.equals(subjectConfirmation);

        if (isInvalidTokenType || isInvalidConfirmation) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
}