package com.example.admin.ApplicationAdmin.Repository;

import com.example.admin.ApplicationAdmin.Entity.CustomerApprovalQueue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerApprovalRepo extends JpaRepository<CustomerApprovalQueue, Long> {

    Boolean existsByCustomerId(String customerId);
    Optional<CustomerApprovalQueue> findByCustomerId(String customerId);
    List<CustomerApprovalQueue> findByCity(String location);
    Optional<CustomerApprovalQueue> findByCustomerIdAndCity(String customerId, String location);
}
