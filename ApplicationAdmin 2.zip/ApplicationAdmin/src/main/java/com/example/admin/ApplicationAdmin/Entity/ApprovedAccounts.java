package com.example.admin.ApplicationAdmin.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "approved_accounts")
public class ApprovedAccounts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long approve_id;

    private String customerId;

    private String adminId;

    private String approvedAt;
}
