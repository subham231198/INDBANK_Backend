package com.example.admin.ApplicationAdmin.Service;

import com.example.admin.ApplicationAdmin.DTO.AdminSessionDTO;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class AdminSessionService {

    @CachePut(value = "adminSessions", key = "#session.getAdminSession()")
    public AdminSessionDTO createSession(AdminSessionDTO session) {
        return session;
    }

    @Cacheable(value = "adminSessions", key = "#sessionToken")
    public AdminSessionDTO getSession(String sessionToken) {
        return null;
    }

    @CacheEvict(value = "adminSessions", key = "#sessionToken")
    public void invalidateSession(String sessionToken) {
    }
}
