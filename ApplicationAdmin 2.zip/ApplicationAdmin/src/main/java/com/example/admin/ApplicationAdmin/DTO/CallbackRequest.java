package com.example.admin.ApplicationAdmin.DTO;

public record CallbackRequest(
        Callback callback
) {
}
