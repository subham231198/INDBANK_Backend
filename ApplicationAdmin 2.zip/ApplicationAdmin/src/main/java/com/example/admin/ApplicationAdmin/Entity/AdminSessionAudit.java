package com.example.admin.ApplicationAdmin.Entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "admin_session_audit")
public class AdminSessionAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditId;

    @Column(name = "admin_id", nullable = false)
    private String adminId;

    @Column(name = "admin_session", unique = true, nullable = false)
    private String adminSessionId;

    @Column(name = "correlation_id", nullable = false)
    private String sessionCorrelationId;

    @Column(name = "login_time", nullable = false)
    private String loggedInTimeStamp;

    @Column(name = "logout_time", nullable = false)
    private String loggedOutTimeStamp;
}
