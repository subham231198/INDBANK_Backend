package com.example.admin.ApplicationAdmin.Configuration;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.util.Collection;
import java.util.Enumeration;

@Component
public class LoggingFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(LoggingFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(response);

        long startTime = System.currentTimeMillis();

        try {
            filterChain.doFilter(wrappedRequest, wrappedResponse);
        } finally {
            long duration = System.currentTimeMillis() - startTime;

            logRequest(wrappedRequest);
            logResponse(wrappedResponse, duration);

            wrappedResponse.copyBodyToResponse();
        }
    }

    private void logRequest(ContentCachingRequestWrapper request) {
        logger.info("\n" +
                "╔══════════════════════════════════════════════════════════════════╗\n" +
                "║                           REQUEST                                ║\n" +
                "╚══════════════════════════════════════════════════════════════════╝");

        logger.info("┌─────────────────────────────────────────────────────────────────┐");
        logger.info("│ METHOD      : {}", request.getMethod());
        logger.info("│ URI         : {}", request.getRequestURI());
        logger.info("│ QUERY       : {}", request.getQueryString());
        logger.info("│ PROTOCOL    : {}", request.getProtocol());
        logger.info("│ REMOTE ADDR : {}", request.getRemoteAddr());
        logger.info("│ SESSION ID  : {}", request.getSession().getId());

        logHeaders(request);
        logParameters(request);
        logAuthInfo(request);
        logRequestBody(request);

        logger.info("└─────────────────────────────────────────────────────────────────┘");
    }

    private void logResponse(ContentCachingResponseWrapper response, long duration) {
        logger.info("\n" +
                "╔══════════════════════════════════════════════════════════════════╗\n" +
                "║                           RESPONSE                               ║\n" +
                "╚══════════════════════════════════════════════════════════════════╝");

        logger.info("┌─────────────────────────────────────────────────────────────────┐");
        logger.info("│ STATUS      : {} - {}", response.getStatus(), getStatusMessage(response.getStatus()));
        logger.info("│ DURATION    : {} ms", duration);

        logResponseHeaders(response);
        logResponseBody(response);

        logger.info("└─────────────────────────────────────────────────────────────────┘");
    }

    private void logHeaders(HttpServletRequest request) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ HEADERS:");
        Enumeration<String> headerNames = request.getHeaderNames();
        if (headerNames != null) {
            while (headerNames.hasMoreElements()) {
                String headerName = headerNames.nextElement();
                String headerValue = request.getHeader(headerName);
                logger.info("│   {}: {}", headerName, headerValue);
            }
        }
    }

    private void logResponseHeaders(HttpServletResponse response) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ RESPONSE HEADERS:");
        Collection<String> headerNames = response.getHeaderNames();
        if (headerNames != null) {
            for (String headerName : headerNames) {
                String headerValue = response.getHeader(headerName);
                logger.info("│   {}: {}", headerName, headerValue);
            }
        }
    }

    private void logParameters(HttpServletRequest request) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ PARAMETERS:");
        java.util.Map<String, String[]> parameterMap = request.getParameterMap();
        if (parameterMap != null && !parameterMap.isEmpty()) {
            for (java.util.Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
                logger.info("│   {}: {}", entry.getKey(), String.join(", ", entry.getValue()));
            }
        } else {
            logger.info("│   No parameters");
        }
    }

    private void logAuthInfo(HttpServletRequest request) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ AUTHENTICATION:");

        String authHeader = request.getHeader("Authorization");
        if (authHeader != null) {
            logger.info("│   Authorization: {}", maskAuthToken(authHeader));
        }

        String adminSession = request.getHeader("adminSession");
        if (adminSession != null) {
            logger.info("│   AdminSession: {}", maskAuthToken(adminSession));
        }

        String cookie = request.getHeader("Cookie");
        if (cookie != null) {
            logger.info("│   Cookie: {}", maskCookie(cookie));
        }

        logger.info("│   Auth Type: {}", request.getAuthType());
        logger.info("│   User Principal: {}", request.getUserPrincipal());
    }

    private void logRequestBody(ContentCachingRequestWrapper request) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ REQUEST BODY:");
        byte[] content = request.getContentAsByteArray();
        if (content.length > 0) {
            try {
                String body = new String(content, request.getCharacterEncoding());
                String maskedBody = maskSensitiveData(body);
                if (maskedBody.length() > 500) {
                    logger.info("│   {}", maskedBody.substring(0, 500));
                    logger.info("│   ... (truncated, total {} characters)", maskedBody.length());
                } else {
                    logger.info("│   {}", maskedBody);
                }
            } catch (Exception e) {
                logger.info("│   Unable to read body: {}", e.getMessage());
            }
        } else {
            logger.info("│   No request body");
        }
    }

    private void logResponseBody(ContentCachingResponseWrapper response) {
        logger.info("│─────────────────────────────────────────────────────────────────│");
        logger.info("│ RESPONSE BODY:");
        byte[] content = response.getContentAsByteArray();
        if (content.length > 0) {
            try {
                String body = new String(content, response.getCharacterEncoding());
                String maskedBody = maskSensitiveData(body);
                if (maskedBody.length() > 1000) {
                    logger.info("│   {}", maskedBody.substring(0, 1000));
                    logger.info("│   ... (truncated, total {} characters)", maskedBody.length());
                } else {
                    logger.info("│   {}", maskedBody);
                }
            } catch (Exception e) {
                logger.info("│   Unable to read body: {}", e.getMessage());
            }
        } else {
            logger.info("│   No response body");
        }
    }

    private String getStatusMessage(int statusCode) {
        switch (statusCode) {
            case 200: return "OK";
            case 201: return "Created";
            case 202: return "Accepted";
            case 204: return "No Content";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 409: return "Conflict";
            case 422: return "Unprocessable Entity";
            case 429: return "Too Many Requests";
            case 500: return "Internal Server Error";
            case 502: return "Bad Gateway";
            case 503: return "Service Unavailable";
            default: return "Unknown";
        }
    }

    private String maskAuthToken(String token) {
        if (token == null || token.isEmpty()) return null;
        if (token.startsWith("Bearer ")) {
            String bearerToken = token.substring(7);
            if (bearerToken.length() > 20) {
                return "Bearer " + bearerToken.substring(0, 10) + "..." + bearerToken.substring(bearerToken.length() - 10);
            }
        }
        if (token.length() > 20) {
            return token.substring(0, 10) + "..." + token.substring(token.length() - 10);
        }
        return token;
    }

    private String maskCookie(String cookie) {
        if (cookie == null) return null;
        return cookie.replaceAll("(ADMIN_SESSION=)[^;]*", "$1***MASKED***")
                .replaceAll("(JSESSIONID=)[^;]*", "$1***MASKED***")
                .replaceAll("(XSRF-TOKEN=)[^;]*", "$1***MASKED***");
    }

    private String maskSensitiveData(String data) {
        if (data == null) return null;
        return data.replaceAll("\"password\"\\s*:\\s*\"[^\"]*\"", "\"password\":\"***MASKED***\"")
                .replaceAll("\"tokenId\"\\s*:\\s*\"[^\"]*\"", "\"tokenId\":\"***MASKED***\"")
                .replaceAll("\"otp\"\\s*:\\s*\"[^\"]*\"", "\"otp\":\"***MASKED***\"")
                .replaceAll("\"clientSecret\"\\s*:\\s*\"[^\"]*\"", "\"clientSecret\":\"***MASKED***\"")
                .replaceAll("\"accessToken\"\\s*:\\s*\"[^\"]*\"", "\"accessToken\":\"***MASKED***\"")
                .replaceAll("\"refreshToken\"\\s*:\\s*\"[^\"]*\"", "\"refreshToken\":\"***MASKED***\"");
    }
}