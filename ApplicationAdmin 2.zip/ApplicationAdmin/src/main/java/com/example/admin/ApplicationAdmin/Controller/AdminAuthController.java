package com.example.admin.ApplicationAdmin.Controller;

import com.example.admin.ApplicationAdmin.DTO.CallbackRequest;
import com.example.admin.ApplicationAdmin.Service.AdminAuthenticationService;
import com.example.admin.ApplicationAdmin.Service.OTPService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Base64;

@RestController
@Tag(name = "Admin Authentication Controller", description = "Endpoints for admin authentication, OTP generation, and verification")
public class AdminAuthController {

    private static final String ACCESS_DENIED = "Access Denied";
    private static final String WEB_CHANNEL = "WEB";
    private static final String SERVICE_TYPE = "Service";
    private static final String AUTH_INDEX_VALUE = "adminAuthService";

    @Autowired
    private AdminAuthenticationService authenticationService;

    @Autowired
    private OTPService otpService;

    @Operation(
            summary = "Authenticate admin user",
            description = "Authenticates admin using username, password, and OTP with channel validation"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Authentication successful"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters or missing headers"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid credentials or channel"),
            @ApiResponse(responseCode = "403", description = "Missing required query parameters")
    })
    @PostMapping(
            value = "/v1/api/authenticate",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<?> adminAuthentication(
            @Parameter(description = "Authentication type (must be 'Service')", required = true, example = "Service")
            @RequestParam(value = "type") String type,

            @Parameter(description = "Authentication index value (must be 'adminAuthService')", required = true, example = "adminAuthService")
            @RequestParam(value = "authIndexValue") String authIndexValue,

            @Parameter(description = "Request source channel (must be WEB)", required = true, example = "WEB")
            @RequestHeader(value = "X-Channel") String channel,

            @Parameter(description = "Unique correlation ID for request tracking", required = true, example = "corr_12345")
            @RequestHeader(value = "X-CorrelationId") String correlationId,

            @Parameter(description = "Callback request containing username, password, and OTP", required = true)
            @RequestBody CallbackRequest request,

            HttpServletResponse response
    ) {
        validateQueryParameters(type, authIndexValue);
        validateAuthenticationType(type, authIndexValue);
        validateCorrelationId(correlationId);
        validateChannel(channel);
        validateWebChannelAccess(channel);

        String username = extractUsername(request);
        String password = extractPassword(request);
        String otp = extractOtp(request);

        validateCredentials(username, password, otp);

        return authenticationService.adminAuthentication(username, password, otp, correlationId, response);
    }

    @Operation(
            summary = "Generate OTP for admin authentication",
            description = "Generates a one-time password (OTP) using base64 encoded client credentials"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OTP generated successfully"),
            @ApiResponse(responseCode = "401", description = "Access denied - invalid OTP key format")
    })
    @GetMapping(value = "/v1/auth/otp")
    public ResponseEntity<?> generateOtp(
            @Parameter(description = "Base64 encoded OTP key in format 'clientId:clientSecret'", required = true, example = "Y2xpZW50MTIzOnNlY3JldDQ1Ng==")
            @RequestParam(value = "_otpKey") String otpKey
    ) {
        String decodedCredentials = decodeBase64Credentials(otpKey);
        String[] credentialParts = splitCredentials(decodedCredentials);

        validateCredentialParts(credentialParts);

        String clientId = credentialParts[0].trim();
        String clientSecret = credentialParts[1].trim();

        return otpService.generateOTP(clientId, clientSecret);
    }

    private void validateQueryParameters(String type, String authIndexValue) {
        if (isNullOrEmpty(type) || isNullOrEmpty(authIndexValue)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Missing query params");
        }
    }

    private void validateAuthenticationType(String type, String authIndexValue) {
        if (!SERVICE_TYPE.equals(type) || !AUTH_INDEX_VALUE.equals(authIndexValue)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private void validateCorrelationId(String correlationId) {
        if (isNullOrEmpty(correlationId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "X-CorrelationId cannot be empty or null");
        }
    }

    private void validateChannel(String channel) {
        if (isNullOrEmpty(channel)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "X-Channel cannot be empty or null");
        }
    }

    private void validateWebChannelAccess(String channel) {
        if (!WEB_CHANNEL.equalsIgnoreCase(channel)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private String extractUsername(CallbackRequest request) {
        return request.callback().nameCallback().value();
    }

    private String extractPassword(CallbackRequest request) {
        return request.callback().passwordCallback().value();
    }

    private String extractOtp(CallbackRequest request) {
        return request.callback().otpCallback().value();
    }

    private void validateCredentials(String username, String password, String otp) {
        if (isNullOrEmpty(username)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username cannot be empty or null");
        }
        if (isNullOrEmpty(password)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Password cannot be empty or null");
        }
        if (isNullOrEmpty(otp)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Otp cannot be empty or null");
        }
    }

    private String decodeBase64Credentials(String otpKey) {
        return new String(Base64.getDecoder().decode(otpKey));
    }

    private String[] splitCredentials(String decodedCredentials) {
        return decodedCredentials.split(":");
    }

    private void validateCredentialParts(String[] parts) {
        if (parts.length < 2 || isNullOrEmpty(parts[0]) || isNullOrEmpty(parts[1])) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, ACCESS_DENIED);
        }
    }

    private boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
}