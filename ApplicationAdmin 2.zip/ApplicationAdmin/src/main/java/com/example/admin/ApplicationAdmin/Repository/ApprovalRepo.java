package com.example.admin.ApplicationAdmin.Repository;

import com.example.admin.ApplicationAdmin.Entity.ApprovedAccounts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ApprovalRepo extends JpaRepository<ApprovedAccounts, Long> {

    Boolean existsByCustomerId(String customerId);
}
