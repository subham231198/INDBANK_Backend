package com.example.Ind.Auth.AuthenticationService.DTO;


import java.time.Instant;

public record OTPServiceDTO(
        String adminId,

        String otp,

        Instant issuedAt,

        Instant expiry
) {
}
