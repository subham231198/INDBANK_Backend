package com.example.Ind.Auth.AuthenticationService.Controller;

import com.example.Ind.Auth.AuthenticationService.DTO.CustomerSessionDTO;
import com.example.Ind.Auth.AuthenticationService.DTO.UserAuthDTO;
import com.example.Ind.Auth.AuthenticationService.Service.CustomerSessionCacheService;
import com.example.Ind.Auth.AuthenticationService.Service.SessionAttributesService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class OAuth2CustomHandler extends SessionAttributesService{

    @Autowired
    private UserAuthDTO userAuthDTO;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private CustomerSessionCacheService customerSessionCacheService;

    private static final Logger logger = LogManager.getLogger(OAuth2CustomHandler.class);

    @GetMapping("/v1/oauth/authorize")
    public ResponseEntity<?> initiateAuthorization(
            @RequestParam("client_id") String clientId,
            @RequestParam("grant_type") String grant,
            @RequestParam("response_type") String responseType,
            @RequestParam(value = "redirect_uri", required = false) String redirectURI,
            @RequestParam("scope") String scope,
            @RequestHeader("X-CustomerSessionId") String customerSessionId
    ) throws JsonProcessingException {
        Optional<CustomerSessionDTO> sessionDTO = Optional.ofNullable(customerSessionCacheService.getCustomerSession(customerSessionId));
        if(!sessionDTO.isPresent() || !validSessionExpiry(sessionDTO.get().getExpiresAt()))
        {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "invalid_customer_authentication"));
        }

        if (!isValidClient(clientId)) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "invalid_client"));
        }

        if (!isValidRedirectUri(clientId, redirectURI)) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "redirect_uri does not match a pre-registered value"));
        }

        if (!formLogin()) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "invalid_authentication"));
        }

        String authorizationUrl = UriComponentsBuilder
                .fromHttpUrl("http://localhost:7079/oauth2/authorize")
                .queryParam("response_type", responseType)
                .queryParam("client_id", clientId)
                .queryParam("redirect_uri", redirectURI)
                .queryParam("scope", scope)
                .build()
                .toUriString();

        try {

            ResponseEntity<String> response = restTemplate.exchange(
                    authorizationUrl,
                    HttpMethod.GET,
                    new HttpEntity<>(new HttpHeaders()),
                    String.class
            );

            logger.info("Response Code: {}", response.getStatusCode());

            String location = response.getHeaders().getFirst(HttpHeaders.LOCATION);

            HttpHeaders outHeaders = new HttpHeaders();

            logger.info("Location: {}", location);

            if (location != null && location.contains("code=")) {
                String code = extractCodeFromLocation(location);
                outHeaders.setLocation(URI.create(redirectURI + "?code=" + code));
                return new ResponseEntity<>(outHeaders, HttpStatus.FOUND);
            }

            outHeaders.setLocation(URI.create(redirectURI + "/error"));
            return new ResponseEntity<>(outHeaders, HttpStatus.FOUND);

        } catch (HttpClientErrorException ex) {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode error = mapper.readTree(ex.getResponseBodyAsString());

            return ResponseEntity
                    .status(ex.getStatusCode())
                    .body(error);
        }
    }

    @GetMapping("/callback")
    public String handleCallback(@RequestParam("code") String code) {

        String tokenUrl = "http://localhost:9091/oauth2/token";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        String clientCredentials = "5acb384e-51d2-4528-b6af-3ba50201216f:your-client-secret";
        headers.set("Authorization",
                "Basic " + Base64.getEncoder().encodeToString(clientCredentials.getBytes()));

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "authorization_code");
        body.add("code", code);
        body.add("redirect_uri", "http://localhost:9091/callback");

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    tokenUrl,
                    HttpMethod.POST,
                    request,
                    String.class
            );

            return response.getBody();

        } catch (Exception e) {
            return "Error exchanging code for token: " + e.getMessage();
        }
    }

    private boolean isValidClient(String clientId) {
        return clientId != null && clientId.matches("[a-zA-Z0-9\\-]+");
    }

    private boolean isValidRedirectUri(String clientId, String redirectUri) {
        return !redirectUri.isEmpty() && !redirectUri.isBlank() && !clientId.isEmpty() && !clientId.isBlank();
    }

    private boolean formLogin() {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        logger.info("{}, {}", userAuthDTO.getUsername(), userAuthDTO.getPassword());
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("username", userAuthDTO.getUsername());
        form.add("password", userAuthDTO.getPassword());

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(form, headers);

        ResponseEntity<String> response = restTemplate.postForEntity(
                "http://localhost:7079/login",
                request,
                String.class
        );

        return response.getStatusCode().is3xxRedirection();
    }

    private String extractCodeFromLocation(String location) {
        String codeParam = "code=";
        int startIndex = location.indexOf(codeParam) + codeParam.length();
        int endIndex = location.indexOf("&", startIndex);
        if (endIndex == -1) {
            endIndex = location.length();
        }
        return location.substring(startIndex, endIndex);
    }
}