package com.example.Ind.Auth.AuthenticationService.Exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    Map<String, Object> responseBody = new LinkedHashMap<>();

    @ExceptionHandler(InvalidUsernameException.class)
    public ResponseEntity<?> handleInvalidUsernameException(InvalidUsernameException ex) {
       responseBody.put("code", 401);
       responseBody.put("reason", "Unauthorized");
       responseBody.put("message", "Invalid username");
       return ResponseEntity.status(401).body(responseBody);
    }

    @ExceptionHandler(InvalidPasswordException.class)
    public ResponseEntity<?> handleInvalidPasswordException(InvalidPasswordException ex) {
        responseBody.put("code", 401);
        responseBody.put("reason", "Unauthorized");
        responseBody.put("message", "Invalid password");
        return ResponseEntity.status(401).body(responseBody);
    }

    @ExceptionHandler(InvalidOTPException.class)
    public ResponseEntity<?> handleInvalidOTPException(InvalidOTPException ex) {
        responseBody.put("code", 401);
        responseBody.put("reason", "Unauthorized");
        responseBody.put("message", "Invalid OTP");
        return ResponseEntity.status(401).body(responseBody);
    }

    @ExceptionHandler(PasswordLockedException.class)
    public ResponseEntity<?> handlePasswordLockedException(PasswordLockedException ex) {
        responseBody.put("code", 401);
        responseBody.put("reason", "Unauthorized");
        responseBody.put("message", "Password is locked");
        return ResponseEntity.status(423).body(responseBody);
    }

    @ExceptionHandler(OTPLockedException.class)
    public ResponseEntity<?> handleOTPLockedException(OTPLockedException ex) {
        responseBody.put("code", 401);
        responseBody.put("reason", "Unauthorized");
        responseBody.put("message", "OTP is locked");
        ex.printStackTrace();
        return ResponseEntity.status(401).body(responseBody);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<?> handleAccessDeniedException(AccessDeniedException ex) {
        responseBody.put("code", 401);
        responseBody.put("reason", "Unauthorized");
        responseBody.put("message", "Access denied");
        ex.printStackTrace();
        return ResponseEntity.status(401).body(responseBody);
    }

    @ExceptionHandler(MissingQueryParameterException.class)
    public ResponseEntity<?> handleMissingQueryParamException(Exception ex) {
        responseBody.put("code", 400);
        responseBody.put("reason", "Bad Request");
        responseBody.put("message", "Missing required query parameter");
        ex.printStackTrace();
        return ResponseEntity.status(400).body(responseBody);
    }

    @ExceptionHandler(MissingSessionIdException.class)
    public ResponseEntity<?> handleMissingSessionIdException(Exception ex){
        responseBody.put("code", 400);
        responseBody.put("reason", "Bad Request");
        responseBody.put("message", "tokenId cannot be empty or null!");
        ex.printStackTrace();
        return ResponseEntity.status(400).body(responseBody);
    }

    @ExceptionHandler(MissingChannelException.class)
    public ResponseEntity<?> handleMissingChannelException(Exception ex){
        responseBody.put("code", 400);
        responseBody.put("reason", "Bad Request");
        responseBody.put("message", "X-Channel cannot be empty or null!");
        return ResponseEntity.status(400).body(responseBody);
    }

    @ExceptionHandler(InvalidSessionException.class)
    public ResponseEntity<?> handleInvalidSessionException(InvalidSessionException ex) {
        responseBody.put("isSessionValid", false);
        return ResponseEntity.status(200).body(responseBody);
    }
}
